var app = app || {};

app.FlowCollection = Backbone.Collection.extend({
  model: app.Flow
});