var app = app || {};

  $(function() {
  	
    app.instance = new app.AppView();

  });